<?php

/**
 * This is the model class for table "user_profile".
 *
 * The followings are the available columns in table 'user_profile':
 * @property string $ID
 * @property string $USER_NAME
 * @property string $PASSWORD
 * @property string $EMAIL_ID
 * @property string $ORGANIZATION
 * @property string $GENDER
 * @property string $CITY
 * @property string $STATE
 * @property string $COUNTRY
 */
class UserProfileForm extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return UserProfileForm the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_profile';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('USER_NAME, PASSWORD, EMAIL_ID, ORGANIZATION, GENDER, CITY, STATE, COUNTRY', 'required'),
			array('USER_NAME, PASSWORD, EMAIL_ID, ORGANIZATION', 'length', 'max'=>48),
			array('GENDER', 'length', 'max'=>4),
			array('CITY, STATE, COUNTRY', 'length', 'max'=>24),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('ID, USER_NAME, PASSWORD, EMAIL_ID, ORGANIZATION, GENDER, CITY, STATE, COUNTRY', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'ID' => 'ID',
			'USER_NAME' => 'User Name',
			'PASSWORD' => 'Password',
			'EMAIL_ID' => 'Email',
			'ORGANIZATION' => 'Organization',
			'GENDER' => 'Gender',
			'CITY' => 'City',
			'STATE' => 'State',
			'COUNTRY' => 'Country',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('ID',$this->ID,true);
		$criteria->compare('USER_NAME',$this->USER_NAME,true);
		$criteria->compare('PASSWORD',$this->PASSWORD,true);
		$criteria->compare('EMAIL_ID',$this->EMAIL_ID,true);
		$criteria->compare('ORGANIZATION',$this->ORGANIZATION,true);
		$criteria->compare('GENDER',$this->GENDER,true);
		$criteria->compare('CITY',$this->CITY,true);
		$criteria->compare('STATE',$this->STATE,true);
		$criteria->compare('COUNTRY',$this->COUNTRY,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}