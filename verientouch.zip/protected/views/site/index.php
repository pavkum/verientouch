<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<div id="welcomebanner">
	<table id=indextable>
		<td > 
			<div>
				<h1> Welcome To verientouch <h1>
				
				<p> We are neither a company nor an organization. We are a group of people who are passionate about what we do. Through this portal we aim to deliver quality services for the well being of all.</p>
			</div>
		</td>

		<td>
			<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/united.jpg" width="300px" height="200px"/>
		</td>

	</table>
</div>

