<?php

	$Test = "sample"

?>
<div>

<?php echo $Test ?>

</div>
