<?php

$this->pageTitle=Yii::app()->name . ' - Error verifying Email';

?>

<div id="validationheader">Email Verification Failed</div>
<div id="container">
	<p> Some where something went wrong. Please read faqs<p>
	<br>
	<p> Please <?php echo CHtml::link('here',array('signup')); ?> here to contact us in case of any queries </p>

</div>
