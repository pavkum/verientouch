<?php $this->beginContent('//layouts/main'); ?>
<div class="art-layout-cell art-content">
    <div class="art-box art-post">
        <div class="art-box-body art-post-body">
            <div class="art-post-inner art-article">
                
                    <!-- article-content -->
                    <?php echo $content; ?>
					<div class="cleared"></div>

            </div>
            <div class="cleared"></div>
        </div>
    </div>
</div>
<?php $this->endContent(); ?>
