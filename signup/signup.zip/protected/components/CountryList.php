<?php

class CountryList{

	public static function getCountryList(){
		$countryArray = Yii::app()->db->createCommand()
				->select('COUNTRY')
				->from('country_list')
				->queryAll();

		$countries = array();

		foreach($countryArray as $country){
			array_push($countries, $country['COUNTRY']);

		}

		return $countries;
	}

}


